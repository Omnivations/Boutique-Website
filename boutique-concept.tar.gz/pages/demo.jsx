import Head from 'next/head';
import { useState } from 'react';

// Import components for testing
import Carousel from '../components/Carousel';
import CalendarWidget from '../components/CalendarWidget';
import ProductCard from '../components/ProductCard';
import SearchBox from '../components/SearchBox';
import ChatWidget from '../components/ChatWidget';

// Import styles
import '../styles/globals.css';
import '../styles/components.css';

export default function Demo() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [searchResults, setSearchResults] = useState([]);

  // Sample data
  const carouselItems = [
    {
      image: '/api/placeholder/800/400',
      title: 'Elegant Wedding Gown',
      description: 'Beautiful lace wedding dress with train',
      price: '₱800/day',
      link: '/gowns/elegant-wedding'
    },
    {
      image: '/api/placeholder/800/400',
      title: 'Princess Ball Gown',
      description: 'Fairy tale princess dress in royal blue',
      price: '₱450/day',
      link: '/gowns/princess-ball'
    },
    {
      image: '/api/placeholder/800/400',
      title: 'Vintage Evening Dress',
      description: '1920s inspired evening gown',
      price: '₱350/day',
      link: '/gowns/vintage-evening'
    }
  ];

  const sampleProduct = {
    id: 1,
    name: 'Royal Velvet Gown',
    image: '/api/placeholder/300/250',
    rentalPrice: 600,
    originalPrice: 800,
    description: 'Luxurious velvet gown perfect for formal events and photo shoots.',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Deep Purple', 'Emerald Green', 'Midnight Blue'],
    maxQuantity: 2,
    featured: true
  };

  const retailProduct = {
    id: 2,
    name: 'Gold Statement Necklace',
    image: '/api/placeholder/300/250',
    price: 1250,
    description: 'Elegant gold-plated statement necklace with cubic zirconia.',
    maxQuantity: 10,
    isNew: true
  };

  const availableDates = [
    '2024-02-15', '2024-02-16', '2024-02-17', '2024-02-20', '2024-02-21',
    '2024-02-22', '2024-02-23', '2024-02-24', '2024-02-27', '2024-02-28',
    '2024-03-01', '2024-03-02', '2024-03-05', '2024-03-06', '2024-03-07'
  ];

  const unavailableDates = [
    '2024-02-14', '2024-02-18', '2024-02-19', '2024-02-25', '2024-02-26',
    '2024-03-03', '2024-03-04', '2024-03-08'
  ];

  const handleDateSelect = (date, quantity) => {
    setSelectedDate(date);
    console.log(`Selected ${date} with quantity ${quantity}`);
  };

  const handleSearch = (query) => {
    console.log('Searching for:', query);
    setSearchResults([`Result for "${query}"`]);
  };

  const handleRentSelect = (productId, date, quantity) => {
    alert(`Rent product ${productId} on ${date} (qty: ${quantity})`);
  };

  const handlePurchase = (productId, quantity) => {
    alert(`Purchase product ${productId} (qty: ${quantity})`);
  };

  return (
    <>
      <Head>
        <title>Boutique Concept - Component Demo</title>
        <meta name="description" content="Testing page for Boutique Concept components" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        {/* Fonts */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link 
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600&family=Dancing+Script:wght@400;600;700&display=swap" 
          rel="stylesheet" 
        />
      </Head>

      <div style={{ minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          
          {/* Header */}
          <header style={{ textAlign: 'center', marginBottom: '4rem' }}>
            <h1 style={{ 
              fontFamily: 'var(--font-accent)', 
              fontSize: '3rem', 
              color: 'var(--gold-primary)', 
              marginBottom: '1rem' 
            }}>
              Component Demo
            </h1>
            <p style={{ fontSize: '1.2rem', color: '#666' }}>
              Test all Boutique Concept UI components
            </p>
          </header>

          {/* Search Box Demo */}
          <section style={{ marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Search Component</h2>
            <SearchBox
              placeholder="Search boutique items..."
              onSearch={handleSearch}
              recentSearches={['Wedding dress', 'Princess costume', 'Evening gown']}
              popularSearches={['Ball gown', 'Superhero costume', 'Colored contacts', 'Tiara']}
            />
            {searchResults.length > 0 && (
              <div style={{ marginTop: '1rem', padding: '1rem', background: 'var(--cream)', borderRadius: '8px' }}>
                <strong>Search Results:</strong> {searchResults.join(', ')}
              </div>
            )}
          </section>

          {/* Carousel Demo */}
          <section style={{ marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Carousel Component</h2>
            <Carousel
              title="Featured Gowns"
              items={carouselItems}
              autoPlay={true}
              autoPlayDelay={3000}
              showArrows={true}
              showDots={true}
            />
          </section>

          {/* Calendar Demo */}
          <section style={{ marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Calendar Widget</h2>
            <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap', alignItems: 'flex-start' }}>
              <div>
                <h3>Rental Calendar</h3>
                <CalendarWidget
                  availableDates={availableDates}
                  unavailableDates={unavailableDates}
                  onDateSelect={handleDateSelect}
                  selectedDate={selectedDate}
                  maxQuantity={3}
                />
              </div>
              {selectedDate && (
                <div style={{ 
                  background: 'var(--cream)', 
                  padding: '1.5rem', 
                  borderRadius: '12px',
                  maxWidth: '300px'
                }}>
                  <h4>Selection Details</h4>
                  <p><strong>Selected Date:</strong> {selectedDate}</p>
                  <p>Calendar widget successfully captured the date selection!</p>
                </div>
              )}
            </div>
          </section>

          {/* Product Cards Demo */}
          <section style={{ marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Product Cards</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
              
              {/* Rental Product */}
              <div>
                <h3 style={{ marginBottom: '1rem' }}>Rental Product</h3>
                <ProductCard
                  product={sampleProduct}
                  isRental={true}
                  onRentSelect={handleRentSelect}
                  availableDates={availableDates}
                  unavailableDates={unavailableDates}
                />
              </div>

              {/* Retail Product */}
              <div>
                <h3 style={{ marginBottom: '1rem' }}>Retail Product</h3>
                <ProductCard
                  product={retailProduct}
                  isRental={false}
                  onPurchase={handlePurchase}
                />
              </div>
            </div>
          </section>

          {/* Styling Demo */}
          <section style={{ marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Styling System</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '2rem' }}>
              
              {/* Colors */}
              <div className="card">
                <div className="card-header">
                  <h3>Color Palette</h3>
                </div>
                <div className="card-body">
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ width: '30px', height: '30px', background: 'var(--gold-primary)', borderRadius: '4px' }}></div>
                      <span>Gold Primary</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ width: '30px', height: '30px', background: 'var(--gold-light)', borderRadius: '4px' }}></div>
                      <span>Gold Light</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ width: '30px', height: '30px', background: 'var(--cream)', borderRadius: '4px' }}></div>
                      <span>Cream</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div style={{ width: '30px', height: '30px', background: 'var(--charcoal)', borderRadius: '4px' }}></div>
                      <span>Charcoal</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Buttons */}
              <div className="card">
                <div className="card-header">
                  <h3>Button Styles</h3>
                </div>
                <div className="card-body">
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                    <button className="btn btn-primary">Primary Button</button>
                    <button className="btn btn-secondary">Secondary Button</button>
                    <button className="btn btn-outline">Outline Button</button>
                  </div>
                </div>
              </div>

              {/* Typography */}
              <div className="card">
                <div className="card-header">
                  <h3>Typography</h3>
                </div>
                <div className="card-body">
                  <h1 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>Heading 1</h1>
                  <h2 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>Heading 2</h2>
                  <h3 style={{ fontSize: '1.1rem', marginBottom: '0.5rem' }}>Heading 3</h3>
                  <p style={{ fontSize: '1rem', marginBottom: '0.5rem' }}>Body text paragraph</p>
                  <p style={{ fontFamily: 'var(--font-accent)', fontSize: '1.2rem', margin: 0 }}>Dancing Script</p>
                </div>
              </div>
            </div>
          </section>

          {/* Responsive Demo */}
          <section style={{ marginBottom: '4rem' }}>
            <h2 style={{ marginBottom: '2rem' }}>Responsive Behavior</h2>
            <div style={{ 
              background: 'var(--cream)', 
              padding: '2rem', 
              borderRadius: '12px',
              textAlign: 'center'
            }}>
              <p>Resize your browser window to see responsive behavior in action:</p>
              <ul style={{ textAlign: 'left', maxWidth: '400px', margin: '1rem auto' }}>
                <li>Navigation collapses on mobile</li>
                <li>Product grid adjusts columns</li>
                <li>Carousel shows/hides navigation</li>
                <li>Calendar optimizes for touch</li>
                <li>Search suggestions adapt</li>
              </ul>
            </div>
          </section>
        </div>

        {/* Chat Widget */}
        <ChatWidget
          whatsappNumber="639123456789"
          messengerUrl="https://m.me/boutique-demo"
          position="bottom-right"
        />
      </div>
    </>
  );
}