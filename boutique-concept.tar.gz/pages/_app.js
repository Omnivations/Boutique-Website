// Import global styles here (required by Next.js)
import '../styles/globals.css';
import '../styles/components.css';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />;
}