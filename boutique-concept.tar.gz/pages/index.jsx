import Head from 'next/head';
import { useState, useEffect } from 'react';
import HomePage from '../components/HomePage';

export default function Home() {
  const [mounted, setMounted] = useState(false);

  // Ensure component only renders on client to prevent hydration mismatches
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null;
  }

  return (
    <>
      <Head>
        <title>Boutique Elegance - Premium Costume & Gown Rentals</title>
        <meta 
          name="description" 
          content="Rent stunning costumes, cosplay outfits, elegant gowns, and accessories for your special occasions. Premium quality, affordable prices." 
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#D4AF37" />
        
        {/* Open Graph / Social Media */}
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Boutique Elegance - Premium Costume & Gown Rentals" />
        <meta property="og:description" content="Rent stunning costumes, cosplay outfits, elegant gowns, and accessories for your special occasions." />
        <meta property="og:url" content="https://boutique-elegance.com" />
        <meta property="og:image" content="/og-image.jpg" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Boutique Elegance - Premium Costume & Gown Rentals" />
        <meta name="twitter:description" content="Rent stunning costumes, cosplay outfits, elegant gowns, and accessories for your special occasions." />
        <meta name="twitter:image" content="/twitter-image.jpg" />
        
        {/* Favicon */}
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        
        {/* Fonts */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link 
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600&family=Dancing+Script:wght@400;600;700&display=swap" 
          rel="stylesheet" 
        />
        
        {/* Structured Data for SEO */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Store",
              "name": "Boutique Elegance",
              "description": "Premium costume and gown rental service",
              "url": "https://boutique-elegance.com",
              "telephone": "+639123456789",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "123 Fashion Street",
                "addressLocality": "Manila",
                "addressCountry": "PH"
              },
              "openingHoursSpecification": {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "opens": "09:00",
                "closes": "18:00"
              },
              "priceRange": "₱₱",
              "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Rental Services",
                "itemListElement": [
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Product",
                      "name": "Costume Rentals",
                      "category": "Costumes"
                    }
                  },
                  {
                    "@type": "Offer", 
                    "itemOffered": {
                      "@type": "Product",
                      "name": "Wedding Gown Rentals",
                      "category": "Wedding"
                    }
                  },
                  {
                    "@type": "Offer",
                    "itemOffered": {
                      "@type": "Product", 
                      "name": "Cosplay Outfits",
                      "category": "Cosplay"
                    }
                  }
                ]
              }
            })
          }}
        />
      </Head>

      <HomePage />
    </>
  );
}

// Optional: Add getStaticProps for pre-loading data
export async function getStaticProps() {
  // In a real app, you'd fetch data from your CMS or API here
  // For now, we'll just return empty props since we're using mock data
  
  return {
    props: {
      // You could pre-load featured products, carousel data, etc. here
    },
    // Revalidate every hour in production
    revalidate: 3600,
  };
}