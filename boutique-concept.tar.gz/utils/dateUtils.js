// Date utility functions for the Boutique Concept project

/**
 * Format date for display
 * @param {string|Date} date - Date to format
 * @param {string} format - Format type ('short', 'long', 'medium')
 * @returns {string} Formatted date string
 */
export const formatDate = (date, format = 'medium') => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  const options = {
    short: { month: 'short', day: 'numeric' },
    medium: { month: 'short', day: 'numeric', year: 'numeric' },
    long: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }
  };

  return dateObj.toLocaleDateString('en-US', options[format] || options.medium);
};

/**
 * Generate date key for calendar operations
 * @param {Date} date - Date object
 * @returns {string} Date key in YYYY-MM-DD format
 */
export const getDateKey = (date) => {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};

/**
 * Check if a date is available for rental
 * @param {string} dateKey - Date in YYYY-MM-DD format
 * @param {string[]} availableDates - Array of available date keys
 * @param {string[]} unavailableDates - Array of unavailable date keys
 * @returns {string} 'available', 'unavailable', or 'neutral'
 */
export const getDateAvailability = (dateKey, availableDates = [], unavailableDates = []) => {
  if (unavailableDates.includes(dateKey)) return 'unavailable';
  if (availableDates.includes(dateKey)) return 'available';
  return 'neutral';
};

/**
 * Generate array of dates for a given month
 * @param {number} year - Year
 * @param {number} month - Month (0-based)
 * @returns {Array} Array of date objects for the month
 */
export const getMonthDates = (year, month) => {
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const dates = [];

  for (let day = 1; day <= lastDay.getDate(); day++) {
    dates.push(new Date(year, month, day));
  }

  return dates;
};

/**
 * Check if date is in business hours
 * @param {Date} date - Date to check
 * @param {Object} businessHours - Business hours config
 * @returns {boolean} True if within business hours
 */
export const isBusinessHours = (date = new Date(), businessHours = { start: 9, end: 18 }) => {
  const hour = date.getHours();
  return hour >= businessHours.start && hour < businessHours.end;
};

/**
 * Calculate rental duration in days
 * @param {string} startDate - Start date in YYYY-MM-DD format
 * @param {string} endDate - End date in YYYY-MM-DD format
 * @returns {number} Number of days
 */
export const calculateRentalDays = (startDate, endDate) => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const timeDiff = end.getTime() - start.getTime();
  return Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // Include both start and end days
};

/**
 * Get next available date from a list
 * @param {string[]} availableDates - Array of available dates
 * @param {Date} fromDate - Start looking from this date
 * @returns {string|null} Next available date or null
 */
export const getNextAvailableDate = (availableDates, fromDate = new Date()) => {
  const fromDateKey = getDateKey(fromDate);
  
  return availableDates
    .filter(date => date >= fromDateKey)
    .sort()[0] || null;
};

/**
 * Check if date is in the past
 * @param {string|Date} date - Date to check
 * @returns {boolean} True if date is in the past
 */
export const isPastDate = (date) => {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  dateObj.setHours(0, 0, 0, 0);
  
  return dateObj < today;
};

/**
 * Generate mock available dates for testing
 * @param {number} daysFromNow - Start generating from X days from now
 * @param {number} totalDays - Total days to generate
 * @param {number} availabilityRate - Percentage of days that should be available (0-1)
 * @returns {string[]} Array of available date keys
 */
export const generateMockAvailableDates = (daysFromNow = 1, totalDays = 30, availabilityRate = 0.7) => {
  const availableDates = [];
  const startDate = new Date();
  startDate.setDate(startDate.getDate() + daysFromNow);

  for (let i = 0; i < totalDays; i++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(startDate.getDate() + i);
    
    // Make it less likely to be available on weekends for realistic simulation
    const isWeekend = currentDate.getDay() === 0 || currentDate.getDay() === 6;
    const weekendPenalty = isWeekend ? 0.3 : 0;
    
    if (Math.random() > (1 - availabilityRate + weekendPenalty)) {
      availableDates.push(getDateKey(currentDate));
    }
  }

  return availableDates.sort();
};