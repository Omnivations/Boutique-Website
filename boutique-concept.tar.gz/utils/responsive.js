// Responsive utility functions for the Boutique Concept project

/**
 * Standard breakpoints used throughout the app
 */
export const breakpoints = {
  xs: 480,
  sm: 640,
  md: 768,
  lg: 1024,
  xl: 1200,
  '2xl': 1536
};

/**
 * Check if current viewport matches a breakpoint
 * @param {string} breakpoint - Breakpoint name ('sm', 'md', 'lg', etc.)
 * @param {string} direction - 'up' for min-width, 'down' for max-width
 * @returns {boolean} True if viewport matches
 */
export const useBreakpoint = (breakpoint, direction = 'up') => {
  if (typeof window === 'undefined') return false;
  
  const width = window.innerWidth;
  const breakpointValue = breakpoints[breakpoint];
  
  return direction === 'up' ? width >= breakpointValue : width < breakpointValue;
};

/**
 * Get current device type based on viewport width
 * @returns {string} 'mobile', 'tablet', or 'desktop'
 */
export const getDeviceType = () => {
  if (typeof window === 'undefined') return 'desktop';
  
  const width = window.innerWidth;
  
  if (width < breakpoints.md) return 'mobile';
  if (width < breakpoints.lg) return 'tablet';
  return 'desktop';
};

/**
 * Generate responsive class names based on viewport
 * @param {Object} classes - Object with breakpoint keys and class names
 * @returns {string} Space-separated class names
 */
export const getResponsiveClasses = (classes) => {
  const deviceType = getDeviceType();
  const classArray = [];
  
  // Always include base class if it exists
  if (classes.base) classArray.push(classes.base);
  
  // Add device-specific classes
  if (classes[deviceType]) classArray.push(classes[deviceType]);
  
  return classArray.join(' ');
};

/**
 * Calculate responsive grid columns
 * @param {Object} config - Grid configuration for different breakpoints
 * @returns {number} Number of columns for current viewport
 */
export const getResponsiveColumns = (config = { mobile: 1, tablet: 2, desktop: 3 }) => {
  const deviceType = getDeviceType();
  return config[deviceType] || config.desktop || 3;
};

/**
 * Calculate responsive font sizes using clamp
 * @param {number} min - Minimum font size (in rem)
 * @param {number} preferred - Preferred font size (in vw)
 * @param {number} max - Maximum font size (in rem)
 * @returns {string} CSS clamp value
 */
export const getResponsiveFontSize = (min, preferred, max) => {
  return `clamp(${min}rem, ${preferred}vw, ${max}rem)`;
};

/**
 * Responsive spacing utilities
 * @param {string} size - Size name ('xs', 'sm', 'md', etc.)
 * @param {string} property - CSS property ('padding', 'margin', etc.)
 * @returns {Object} CSS-in-JS style object with responsive spacing
 */
export const getResponsiveSpacing = (size, property = 'padding') => {
  const spacingMap = {
    xs: { mobile: '0.5rem', tablet: '0.75rem', desktop: '1rem' },
    sm: { mobile: '1rem', tablet: '1.25rem', desktop: '1.5rem' },
    md: { mobile: '1.5rem', tablet: '2rem', desktop: '2.5rem' },
    lg: { mobile: '2rem', tablet: '3rem', desktop: '4rem' },
    xl: { mobile: '3rem', tablet: '4rem', desktop: '5rem' }
  };
  
  const deviceType = getDeviceType();
  const spacing = spacingMap[size] || spacingMap.md;
  
  return {
    [property]: spacing[deviceType] || spacing.desktop
  };
};

/**
 * Media query helper for styled-components or CSS-in-JS
 * @param {string} breakpoint - Breakpoint name
 * @param {string} direction - 'up' or 'down'
 * @returns {string} Media query string
 */
export const mediaQuery = (breakpoint, direction = 'up') => {
  const width = breakpoints[breakpoint];
  return direction === 'up' 
    ? `@media (min-width: ${width}px)`
    : `@media (max-width: ${width - 1}px)`;
};

/**
 * Check if device is touch-enabled
 * @returns {boolean} True if touch is supported
 */
export const isTouchDevice = () => {
  if (typeof window === 'undefined') return false;
  return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
};

/**
 * Get safe area insets for mobile devices (iPhone X+ notch support)
 * @returns {Object} Safe area inset values
 */
export const getSafeAreaInsets = () => {
  if (typeof window === 'undefined' || typeof CSS === 'undefined' || !CSS.supports('padding', 'env(safe-area-inset-top)')) {
    return { top: 0, right: 0, bottom: 0, left: 0 };
  }
  
  return {
    top: 'env(safe-area-inset-top)',
    right: 'env(safe-area-inset-right)', 
    bottom: 'env(safe-area-inset-bottom)',
    left: 'env(safe-area-inset-left)'
  };
};

/**
 * Responsive image sizes based on viewport
 * @param {Object} config - Image size configuration
 * @returns {string} Sizes attribute for responsive images
 */
export const getResponsiveImageSizes = (config = {}) => {
  const defaultConfig = {
    mobile: '100vw',
    tablet: '50vw', 
    desktop: '33vw'
  };
  
  const finalConfig = { ...defaultConfig, ...config };
  
  return [
    `(max-width: ${breakpoints.md}px) ${finalConfig.mobile}`,
    `(max-width: ${breakpoints.lg}px) ${finalConfig.tablet}`,
    finalConfig.desktop
  ].join(', ');
};

/**
 * Create responsive container styles
 * @param {string} maxWidth - Maximum container width
 * @param {Object} padding - Responsive padding configuration
 * @returns {Object} CSS-in-JS style object
 */
export const createResponsiveContainer = (maxWidth = '1200px', padding = {}) => {
  const defaultPadding = {
    mobile: '1rem',
    tablet: '1.5rem', 
    desktop: '2rem'
  };
  
  const finalPadding = { ...defaultPadding, ...padding };
  const deviceType = getDeviceType();
  
  return {
    width: '100%',
    maxWidth,
    margin: '0 auto',
    padding: `0 ${finalPadding[deviceType] || finalPadding.desktop}`
  };
};

/**
 * Responsive carousel settings based on viewport
 * @returns {Object} Carousel configuration for current viewport
 */
export const getResponsiveCarouselSettings = () => {
  const deviceType = getDeviceType();
  
  const settings = {
    mobile: {
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      dots: true
    },
    tablet: {
      slidesToShow: 2,
      slidesToScroll: 1,
      arrows: true,
      dots: true
    },
    desktop: {
      slidesToShow: 3,
      slidesToScroll: 1,
      arrows: true,
      dots: false
    }
  };
  
  return settings[deviceType] || settings.desktop;
};